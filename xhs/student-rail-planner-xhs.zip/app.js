
const STATIONS = [
  // 京津冀
  ["北京西","北京",39.895,116.322,1],["北京南","北京",39.865,116.379,1],["北京丰台","北京",39.852,116.301,0],
  ["天津","天津",39.135,117.202,1],["天津西","天津",39.161,117.158,0],["天津南","天津",39.059,117.057,0],
  ["石家庄","石家庄",38.056,114.490,1],["石家庄东","石家庄",38.050,114.602,0],
  ["保定东","保定",38.858,115.498,0],["邯郸东","邯郸",36.610,114.530,0],["邢台东","邢台",37.071,114.550,0],
  ["廊坊","廊坊",39.510,116.750,0],["唐山","唐山",39.622,118.178,0],["秦皇岛","秦皇岛",39.950,119.601,0],
  ["张家口","张家口",40.762,114.887,0],["承德南","承德",40.946,117.930,0],["沧州西","沧州",38.322,116.829,0],
  ["衡水北","衡水",37.732,115.666,0],
  // 山西
  ["太原南","太原",37.750,112.600,1],["太原","太原",37.853,112.571,0],
  ["大同南","大同",40.052,113.361,0],["阳泉北","阳泉",38.049,113.467,0],["长治东","长治",36.201,113.110,0],
  ["晋城东","晋城",35.489,112.830,0],["朔州","朔州",39.317,112.430,0],["晋中","晋中",37.679,112.753,0],
  ["运城北","运城",35.019,111.010,0],["忻州西","忻州",38.414,112.711,0],["临汾西","临汾",36.091,111.480,0],
  ["吕梁","吕梁",37.518,111.141,0],
  // 内蒙古
  ["呼和浩特东","呼和浩特",40.846,111.760,1],["呼和浩特","呼和浩特",40.820,111.654,0],
  ["包头","包头",40.602,109.981,0],["鄂尔多斯","鄂尔多斯",39.620,109.780,0],["乌兰察布","乌兰察布",40.993,113.128,0],
  ["巴彦淖尔","巴彦淖尔",40.749,107.409,0],["乌海","乌海",39.651,106.789,0],["通辽","通辽",43.621,122.249,0],
  ["赤峰","赤峰",42.262,118.947,0],["海拉尔","呼伦贝尔",49.210,119.728,0],
  // 东北
  ["沈阳北","沈阳",41.821,123.435,1],["沈阳","沈阳",41.784,123.399,0],["沈阳南","沈阳",41.661,123.372,0],
  ["大连北","大连",38.980,121.620,1],["大连","大连",38.921,121.619,0],
  ["鞍山西","鞍山",41.111,122.974,0],["抚顺北","抚顺",41.882,123.877,0],["本溪","本溪",41.292,123.765,0],
  ["丹东","丹东",40.124,124.380,0],["锦州南","锦州",41.080,121.141,0],["营口东","营口",40.647,122.401,0],
  ["盘锦","盘锦",41.184,122.074,0],["阜新","阜新",42.021,121.659,0],["辽阳","辽阳",41.265,123.174,0],
  ["铁岭西","铁岭",42.216,123.723,0],["朝阳","朝阳",41.568,120.448,0],["葫芦岛北","葫芦岛",40.752,120.802,0],
  ["长春西","长春",43.830,125.180,1],["长春","长春",43.902,125.308,0],
  ["吉林","吉林",43.874,126.521,0],["四平东","四平",43.171,124.394,0],["延吉西","延吉",42.921,129.462,0],
  ["通化","通化",41.724,125.940,0],["白城","白城",45.630,122.833,0],["松原","松原",45.139,124.820,0],
  ["白山","白山",41.943,126.423,0],
  ["哈尔滨西","哈尔滨",45.632,126.570,1],["哈尔滨","哈尔滨",45.750,126.620,0],["哈尔滨北","哈尔滨",45.893,126.516,0],
  ["齐齐哈尔南","齐齐哈尔",47.311,123.960,0],["牡丹江","牡丹江",44.599,129.590,0],["佳木斯","佳木斯",46.801,130.361,0],
  ["大庆西","大庆",46.631,124.928,0],["鸡西西","鸡西",45.299,130.900,0],["双鸭山西","双鸭山",46.646,131.170,0],
  ["伊春","伊春",47.721,128.853,0],["七台河西","七台河",45.780,131.030,0],["鹤岗","鹤岗",47.351,130.281,0],
  ["黑河","黑河",50.246,127.483,0],["绥化","绥化",46.637,126.986,0],["加格达奇","大兴安岭",50.423,124.121,0],
  // 长三角
  ["上海虹桥","上海",31.197,121.323,1],["上海","上海",31.251,121.456,0],["上海南","上海",31.154,121.428,0],
  ["苏州","苏州",31.329,120.621,0],["苏州北","苏州",31.430,120.621,0],
  ["无锡","无锡",31.568,120.308,0],["无锡东","无锡",31.603,120.430,0],
  ["常州","常州",31.729,119.957,0],["常州北","常州",31.830,119.973,0],
  ["镇江","镇江",32.194,119.425,0],["扬州东","扬州",32.416,119.518,0],["泰州","泰州",32.492,119.921,0],
  ["南通","南通",31.971,120.862,0],["南通西","南通",32.057,120.843,0],
  ["徐州东","徐州",34.281,117.309,1],["徐州","徐州",34.266,117.186,0],
  ["淮安东","淮安",33.610,119.090,0],["盐城","盐城",33.380,120.130,0],["连云港","连云港",34.601,119.160,0],
  ["宿迁","宿迁",33.964,118.290,0],
  ["杭州东","杭州",30.290,120.210,1],["杭州","杭州",30.244,120.178,0],["杭州南","杭州",30.174,120.272,0],
  ["宁波","宁波",29.861,121.549,0],["温州南","温州",27.966,120.640,0],["绍兴北","绍兴",30.099,120.573,0],
  ["嘉兴南","嘉兴",30.721,120.780,0],["湖州","湖州",30.873,120.090,0],["金华","金华",29.079,119.642,0],
  ["衢州","衢州",28.958,118.857,0],["台州西","台州",28.697,121.283,0],["丽水","丽水",28.450,119.910,0],
  ["义乌","义乌",29.327,120.071,0],
  ["南京南","南京",31.970,118.794,1],["南京","南京",32.088,118.790,0],
  ["合肥南","合肥",31.800,117.300,1],["合肥","合肥",31.877,117.283,0],
  ["芜湖","芜湖",31.327,118.361,0],["蚌埠南","蚌埠",32.950,117.400,0],["安庆","安庆",30.509,117.080,0],
  ["黄山北","黄山",29.920,118.240,0],["阜阳西","阜阳",32.928,115.782,0],["淮南南","淮南",32.626,117.012,0],
  ["马鞍山东","马鞍山",31.690,118.484,0],["滁州","滁州",32.319,118.302,0],["六安","六安",31.749,116.488,0],
  ["亳州南","亳州",33.860,115.760,0],["宣城","宣城",30.941,118.749,0],["铜陵北","铜陵",30.943,117.812,0],
  ["池州","池州",30.660,117.483,0],["淮北","淮北",33.954,116.795,0],
  // 东南
  ["福州","福州",26.100,119.300,1],["福州南","福州",25.987,119.380,0],
  ["厦门北","厦门",24.636,118.130,1],["厦门","厦门",24.466,118.110,0],
  ["泉州","泉州",24.879,118.601,0],["漳州","漳州",24.509,117.654,0],["莆田","莆田",25.401,119.010,0],
  ["龙岩","龙岩",25.122,117.031,0],["宁德","宁德",26.659,119.520,0],["南平","南平",26.632,118.169,0],
  ["三明北","三明",26.301,117.800,0],
  // 江西
  ["南昌西","南昌",28.620,115.780,1],["南昌","南昌",28.680,115.860,0],
  ["九江","九江",29.708,116.011,0],["赣州西","赣州",25.780,114.870,0],["赣州","赣州",25.851,114.948,0],
  ["上饶","上饶",28.456,117.961,0],["鹰潭北","鹰潭",28.333,117.063,0],["萍乡北","萍乡",27.681,113.812,0],
  ["新余北","新余",27.832,114.858,0],["宜春","宜春",27.792,114.419,0],["景德镇北","景德镇",29.311,117.204,0],
  ["吉安西","吉安",27.080,114.950,0],["抚州","抚州",28.000,116.340,0],
  // 湖北
  ["武汉","武汉",30.607,114.422,1],["汉口","武汉",30.620,114.255,0],["武昌","武汉",30.528,114.320,0],
  ["襄阳东","襄阳",32.012,112.230,0],["宜昌东","宜昌",30.644,111.380,0],["荆州","荆州",30.340,112.220,0],
  ["十堰东","十堰",32.613,110.780,0],["恩施","恩施",30.281,109.480,0],["黄石北","黄石",30.221,114.982,0],
  ["鄂州","鄂州",30.390,114.890,0],["孝感东","孝感",30.950,113.940,0],["黄冈东","黄冈",30.461,114.938,0],
  ["咸宁北","咸宁",29.872,114.318,0],["荆门","荆门",31.031,112.190,0],["随州","随州",31.690,113.371,0],
  ["仙桃","仙桃",30.360,113.460,0],["潜江","潜江",30.410,112.880,0],["天门南","天门",30.514,113.220,0],
  // 湖南
  ["长沙南","长沙",28.150,113.066,1],["长沙","长沙",28.190,112.990,0],
  ["株洲西","株洲",27.804,113.103,0],["湘潭北","湘潭",27.954,112.932,0],["衡阳东","衡阳",26.901,112.621,0],
  ["岳阳东","岳阳",29.372,113.199,0],["邵阳","邵阳",27.240,111.470,0],["娄底南","娄底",27.701,112.012,0],
  ["常德","常德",29.043,111.702,0],["益阳南","益阳",28.579,112.350,0],["郴州西","郴州",25.780,112.946,0],
  ["永州","永州",26.431,111.617,0],["怀化南","怀化",27.549,109.972,0],["张家界西","张家界",29.148,110.480,0],
  ["吉首东","湘西",28.310,109.713,0],
  // 珠三角
  ["广州南","广州",22.990,113.269,1],["广州","广州",23.147,113.260,0],["广州东","广州",23.151,113.323,0],
  ["深圳北","深圳",22.609,114.028,1],["深圳","深圳",22.533,114.110,0],
  ["佛山西","佛山",23.078,113.025,0],["东莞南","东莞",22.781,114.098,0],
  ["珠海","珠海",22.219,113.528,0],["中山","中山",22.518,113.378,0],["江门","江门",22.573,113.119,0],
  ["肇庆东","肇庆",23.259,112.653,0],["惠州北","惠州",23.177,114.416,0],["惠州南","惠州",22.872,114.531,0],
  ["汕尾","汕尾",22.782,115.382,0],["潮汕","潮州",23.528,116.646,0],["汕头","汕头",23.378,116.660,0],
  ["揭阳","揭阳",23.554,116.381,0],["梅州西","梅州",24.320,116.140,0],["河源东","河源",23.758,114.676,0],
  ["清远","清远",23.700,113.101,0],["韶关","韶关",24.807,113.602,0],["云浮东","云浮",22.982,112.082,0],
  ["湛江西","湛江",21.249,110.331,0],["茂名","茂名",21.654,110.933,0],["阳江","阳江",21.857,111.982,0],
  // 广西
  ["南宁东","南宁",22.840,108.421,1],["南宁","南宁",22.818,108.310,0],
  ["柳州","柳州",24.311,109.390,0],["桂林北","桂林",25.317,110.297,0],["桂林","桂林",25.280,110.289,0],
  ["梧州南","梧州",23.478,111.286,0],["北海","北海",21.478,109.120,0],["钦州东","钦州",21.960,108.630,0],
  ["防城港北","防城港",21.681,108.348,0],["玉林","玉林",22.642,110.182,0],["百色","百色",23.894,106.627,0],
  ["贺州","贺州",24.404,111.559,0],["来宾北","来宾",23.730,109.232,0],["崇左南","崇左",22.398,107.352,0],
  ["贵港","贵港",23.101,109.599,0],
  // 海南
  ["海口东","海口",20.020,110.362,0],["海口","海口",20.028,110.320,0],
  ["三亚","三亚",18.289,109.494,0],["文昌","文昌",19.612,110.758,0],["琼海","琼海",19.240,110.477,0],
  ["万宁","万宁",18.789,110.389,0],["白马井","儋州",19.728,109.221,0],["东方","东方",19.099,108.651,0],
  // 西南
  ["成都东","成都",30.630,104.140,1],["成都","成都",30.700,104.070,0],["成都南","成都",30.610,104.055,0],
  ["成都西","成都",30.688,103.975,0],
  ["绵阳","绵阳",31.473,104.723,0],["德阳","德阳",31.128,104.402,0],["乐山","乐山",29.570,103.754,0],
  ["宜宾西","宜宾",28.779,104.646,0],["泸州","泸州",28.884,105.438,0],["自贡","自贡",29.341,104.784,0],
  ["内江北","内江",29.584,105.058,0],["南充北","南充",30.828,106.088,0],["达州","达州",31.218,107.479,0],
  ["广元","广元",32.443,105.821,0],["攀枝花南","攀枝花",26.552,101.733,0],["遂宁","遂宁",30.510,105.584,0],
  ["眉山东","眉山",30.083,103.840,0],["资阳北","资阳",30.120,104.649,0],["西昌西","凉山",27.887,102.186,0],
  ["重庆北","重庆",29.611,106.547,1],["重庆西","重庆",29.494,106.395,0],["重庆","重庆",29.552,106.543,0],
  ["万州北","重庆",30.807,108.352,0],["涪陵北","重庆",29.688,107.360,0],["永川东","重庆",29.322,105.938,0],
  ["江津","重庆",29.294,106.258,0],
  ["贵阳北","贵阳",26.630,106.640,1],["贵阳","贵阳",26.579,106.705,0],
  ["遵义","遵义",27.722,106.911,0],["六盘水","六盘水",26.590,104.830,0],["毕节","毕节",27.298,105.291,0],
  ["安顺西","安顺",26.257,105.917,0],["凯里南","黔东南",26.568,107.979,0],["都匀东","黔南",26.202,107.554,0],
  ["铜仁","铜仁",27.721,109.186,0],["兴义","黔西南",25.089,104.901,0],
  ["昆明南","昆明",24.880,102.860,1],["昆明","昆明",25.021,102.723,0],
  ["大理","大理",25.654,100.237,0],["丽江","丽江",26.889,100.228,0],["曲靖北","曲靖",25.508,103.772,0],
  ["玉溪","玉溪",24.360,102.547,0],["蒙自","红河",23.369,103.368,0],["普洱","普洱",22.786,100.966,0],
  ["西双版纳","西双版纳",22.011,100.806,0],["保山","保山",25.116,99.166,0],["临沧","临沧",23.889,100.085,0],
  // 青藏
  ["拉萨","拉萨",29.650,91.120,1],["日喀则","日喀则",29.249,88.882,0],["林芝","林芝",29.640,94.360,0],
  ["那曲","那曲",31.474,92.052,0],
  ["西宁","西宁",36.610,101.810,1],["海东西","海东",36.476,102.102,0],["格尔木","海西",36.408,94.900,0],
  // 西北
  ["西安北","西安",34.374,108.937,1],["西安","西安",34.278,108.958,0],
  ["宝鸡南","宝鸡",34.352,107.238,0],["咸阳西","咸阳",34.343,108.670,0],["渭南北","渭南",34.507,109.558,0],
  ["汉中","汉中",33.066,107.028,0],["安康","安康",32.683,109.018,0],["延安","延安",36.590,109.496,0],
  ["榆林","榆林",38.287,109.731,0],
  ["兰州西","兰州",36.070,103.750,1],["兰州","兰州",36.058,103.840,0],
  ["天水南","天水",34.580,105.700,0],["嘉峪关南","嘉峪关",39.762,98.279,0],["张掖西","张掖",38.923,100.453,0],
  ["武威","武威",37.930,102.639,0],["酒泉南","酒泉",39.740,98.491,0],["敦煌","敦煌",40.141,94.683,0],
  ["金昌","金昌",38.499,102.190,0],["陇南","陇南",33.384,104.998,0],["平凉","平凉",35.543,106.657,0],
  ["庆阳","庆阳",35.758,107.641,0],
  ["银川","银川",38.481,106.221,1],["吴忠","吴忠",37.989,106.201,0],["中卫南","中卫",37.488,105.176,0],
  ["石嘴山","石嘴山",38.982,106.382,0],
  ["乌鲁木齐","乌鲁木齐",43.781,87.582,1],["吐鲁番北","吐鲁番",43.022,89.131,0],["哈密","哈密",42.819,93.513,0],
  ["库车","阿克苏",41.701,82.948,0],["阿克苏","阿克苏",41.162,80.264,0],["喀什","喀什",39.469,75.991,0],
  ["和田","和田",37.108,79.933,0],["伊宁","伊宁",43.919,81.280,0],["克拉玛依","克拉玛依",45.580,84.890,0],
  ["奎屯","奎屯",44.428,84.897,0],["石河子","石河子",44.288,86.046,0],["库尔勒","巴音郭楞",41.716,86.177,0],
  // 山东
  ["济南西","济南",36.672,116.880,1],["济南","济南",36.668,117.001,0],["济南东","济南",36.747,117.219,0],
  ["青岛","青岛",36.062,120.318,0],["青岛北","青岛",36.175,120.360,0],
  ["淄博","淄博",36.789,118.052,0],["烟台南","烟台",37.483,121.440,0],["潍坊","潍坊",36.710,119.101,0],
  ["临沂北","临沂",35.104,118.344,0],["济宁北","济宁",35.411,116.589,0],["泰安","泰安",36.183,117.088,0],
  ["德州东","德州",37.458,116.351,0],["威海","威海",37.469,122.120,0],["东营","东营",37.431,118.672,0],
  ["聊城西","聊城",36.456,115.968,0],["滨州","滨州",37.418,118.001,0],["菏泽东","菏泽",35.240,115.463,0],
  ["日照西","日照",35.418,119.516,0],["枣庄","枣庄",34.810,117.319,0],["曲阜东","济宁",35.594,117.016,0],
  // 河南
  ["郑州东","郑州",34.720,113.771,1],["郑州","郑州",34.747,113.656,0],
  ["洛阳龙门","洛阳",34.589,112.516,0],["洛阳","洛阳",34.681,112.469,0],
  ["开封北","开封",34.857,114.288,0],["许昌东","许昌",34.012,113.862,0],["新乡东","新乡",35.311,113.949,0],
  ["安阳东","安阳",36.081,114.398,0],["鹤壁东","鹤壁",35.753,114.282,0],["濮阳东","濮阳",35.771,115.022,0],
  ["商丘","商丘",34.421,115.657,0],["周口东","周口",33.629,114.686,0],["驻马店西","驻马店",33.008,114.051,0],
  ["南阳东","南阳",33.001,112.579,0],["信阳东","信阳",32.161,114.160,0],["平顶山西","平顶山",33.875,112.897,0],
  ["焦作","焦作",35.242,113.239,0],["三门峡南","三门峡",34.767,111.178,0],["漯河西","漯河",33.575,113.988,0],
];
const HUBS = STATIONS.filter(s => s[4]);
const state = {
  ratio: 1.5,
  ratioMax: 2.5, // 绕行比上限(实测校准最优; 网页端可调, 用户值优先)
  budget: 4,
  school: null, home: null,
  trips: [],
  optMode: 'save',
  optBestName: null,
  chainMode: true,    // 联程默认: 多个目的地按顺序串成一条联程路线(整条1次)
  chainEnd: null,     // 串联路线终点(默认=家, 可改为任意想去的地方)
  routeStart: null,   // 路线出发地(默认=学校, 可改为任意起点)
  touched: false,     // 是否已有用户操作(初始不自动滚动)
  chainRound: false,  // 串联模式下整条路线: 单程=1次 / 往返=2次
  _tid: 0,
};

/* ---------- 纯几何/规划逻辑 ---------- */
const R = 6371;
function hav(a, b) {
  const dLat = (b.lat - a.lat) * Math.PI / 180, dLon = (b.lon - a.lon) * Math.PI / 180;
  const s = Math.sin(dLat / 2) ** 2 +
    Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}
function dist(a, b) { return hav(a, b); }

/* 点到"学校↔家"沿线的投影 t 与垂直偏差 p（km，平面近似） */
function corridor(S, H, D) {
  const lat0 = (S.lat + H.lat) / 2 * Math.PI / 180;
  const toX = l => (l.lon - S.lon) * 111.32 * Math.cos(lat0);
  const toY = l => (l.lat - S.lat) * 110.57;
  const hx = toX(H), hy = toY(H), dx = toX(D), dy = toY(D);
  const L2 = hx * hx + hy * hy;
  if (L2 < 1e-6) return { t: 0, p: Math.hypot(dx, dy) };
  const t = (dx * hx + dy * hy) / L2;
  return { t, p: Math.hypot(dx - hx * t, dy - hy * t) };
}

/* 直达覆盖：目的地位于区间沿线带内 */
/* 某点在区间走廊带内? (供出发地/目的地/中转站判定) */
function inIntervalBelt(S, H, P, tLo, tHi, band) {
  const L = dist(S, H);
  if (L < 15) return true; // 退化区间: 无走廊概念, 由直达50km/中转绕行规则约束
  const { t, p } = corridor(S, H, P);
  return t >= tLo && t <= tHi && p <= band;
}

/* ==================== 实测校准规则 v2（58 条实测，2026-08） ====================
 * 可出(直达) = 同城/紧邻(≤50km传播) ∨ (空间带 ∧ 通道网 ∧ ∉区间级例外)
 *  - 空间带: t∈[-0.15,1.2]; 带宽 = 端点内 min(450,max(60,0.55L)) / 端点外 max(75,0.4L)
 *    (实测: 深圳 p=1236km/2559L 可出→端内0.48L; 南宁 t=1.105 可出; 三亚 t=1.203 拦→t上限1.2)
 *  - 通道网: 城市级铁路图 Dijkstra, 绕行比 (rail(S,P)+rail(P,H))/dist(S,H) ≤ RATIO_MAX
 *    (石家庄经京广陇海入京沪1.3✓; 柳州→广州经南广2.5✓; 昆明/北海/厦门1.3~1.8✓)
 *  - 同城/紧邻: 与"区间内站"≤50km 或同城市名(传播一轮) — 湘潭(长株潭)/佛山(广佛)实证
 *  - 例外: 雷州-海南链(湛江/徐闻/海口/三亚/环岛) 不入图→自然拦截; 顽固反例走 BLK2
 */
const RATIO_MAX = 2.5;
/* 区间级例外(实测): 几何/图检全过却真实拦截的支线超端样本 */
const BLK2 = [
  ['武汉', '广州', '深圳'], ['南宁', '济南', '天津'],
  ['海口', '沈阳', '福州'], ['海口', '哈尔滨', '福州'],
];
const RAIL_LINES = [
  ['哈尔滨', '长春', '沈阳', '北京'],                         // 京哈
  ['北京', '石家庄', '太原', '郑州', '信阳', '武汉', '岳阳', '长沙', '衡阳', '广州'], // 京广(+石太/郑太)
  ['北京', '天津', '济南', '徐州', '蚌埠', '南京', '镇江', '常州', '无锡', '苏州', '上海'], // 京沪(补沪宁走廊)
  ['连云港', '徐州', '郑州', '西安', '兰州'],                  // 陇海
  ['兰州', '乌鲁木齐'],                                      // 兰新
  ['西安', '成都'],                                          // 西成/宝成
  ['兰州', '成都'],                                          // 兰渝(近似)
  ['成都', '重庆'], ['重庆', '遵义', '贵阳'],                  // 成渝+渝贵
  ['上海', '嘉兴', '杭州', '南昌', '长沙', '株洲', '贵阳', '昆明'], // 沪昆(补嘉兴)
  ['衡阳', '桂林', '柳州', '南宁'],                           // 湘桂/衡柳
  ['贵阳', '柳州'],                                          // 黔桂
  ['南宁', '昆明'],                                          // 南昆
  ['成都', '昆明'],                                          // 成昆
  ['昆明', '大理'],                                          // 大丽(近似)
  ['南宁', '北海'], ['南宁', '防城港'],                          // 邕北+钦防
  ['南宁', '梧州', '广州'],                                     // 南广(+梧州)
  ['广州', '茂名'],                                          // 江湛(止于茂名; 雷州-海南链不入图)
  ['广州', '深圳'],                                          // 广深
  ['杭州', '宁波', '温州', '福州', '厦门', '深圳'],            // 杭深(沿海)
  ['北京', '南昌', '深圳'],                                  // 京九(近似)
  ['武汉', '黄石'],                                          // 武黄城际
  ['济南', '青岛'], ['青岛', '烟台'],                         // 胶济+青荣
  ['蚌埠', '合肥'],                                          // 合蚌
  ['沈阳', '丹东'], ['沈阳', '大连'],                         // 沈丹+哈大
  ['长春', '延吉'],                                          // 长图
  ['哈尔滨', '牡丹江'], ['哈尔滨', '佳木斯'], ['哈尔滨', '黑河'], // 滨绥/哈佳/北黑(近似)
  ['兰州', '西宁', '拉萨'],                                  // 青藏(近似)
];
let _adjV2 = null;
function railAdj() {
  if (_adjV2) return _adjV2;
  _adjV2 = {};
  const pt = {};
  for (const s of STATIONS) if (!(s[1] in pt)) pt[s[1]] = { lat: s[2], lon: s[3] };
  const add = (a, b) => {
    if (!(a in pt) || !(b in pt)) return;
    (_adjV2[a] = _adjV2[a] || []).push(b);
    (_adjV2[b] = _adjV2[b] || []).push(a);
  };
  for (const line of RAIL_LINES) for (let i = 0; i + 1 < line.length; i++) add(line[i], line[i + 1]);
  _adjV2.pt = pt;
  _adjV2.nodes = new Set(Object.keys(_adjV2));
  return _adjV2;
}
const _djCache = {};
function railDist(city) {
  const g = railAdj();
  if (city in _djCache) return _djCache[city];
  const d = {}; d[city] = 0;
  const done = {};
  while (true) {
    let u = null, duv = Infinity;
    for (const k of Object.keys(d)) if (!done[k] && d[k] < duv) { u = k; duv = d[k]; }
    if (!u) break;
    done[u] = 1;
    for (const v of (g[u] || [])) {
      const w = dist({ lat: g.pt[u].lat, lon: g.pt[u].lon }, { lat: g.pt[v].lat, lon: g.pt[v].lon });
      if (d[v] == null || duv + w < d[v]) d[v] = duv + w;
    }
  }
  _djCache[city] = d;
  return d;
}
/* 空间带: 投影 t∈[-0.15,1.2] + 带宽(端内0.55L≤450 / 端外0.4L≥75) */
function bandOK(S, H, P) {
  const L = dist(S, H);
  // 极短区间(端点几乎同城, L<150): 端点近邻圈≤400km 全可出(实测: 广州⇄佛山27km 下 深圳/珠海/中山/东莞/厦门 全放行)
  if (L < 150) return dist(S, P) <= 600 || dist(H, P) <= 600; // 实测 厦门527km 亦放行; 上界待 苏⇄沪 收紧
  const { t, p } = corridor(S, H, P);
  if (t < -0.15 || t > 1.2) return false;
  // 带宽按侧分开: 端内 0.55L(由通道网兜底); 校侧端点外(t<0) 0.2L·底250(实测: 广州0.29L拦/南昌0.04L放/黑河0.09L放);
// 家侧端点外(t>1) 0.4L(实测: 南宁0.35L放)。广度超过端点时两侧不等, 校侧更严。
const w = (t < 0.0) ? Math.max(250, 0.2 * L)
        : (t > 1.0) ? Math.max(75, 0.4 * L)
        : Math.max(60, 0.55 * L);
  return p <= w;
}
/* 通道网: 两端点经 P 的绕行比 (端点在支线图外时通道退化为空间带) */
function chanOK(S, H, P) {
  const g = railAdj();
  if (!P || !P.city || !S || !S.city || !H || !H.city) return false;
  if (dist(S, H) < 150) return bandOK(S, H, P); // 极短区间: 通道退化为近邻圈判定(600km)
  if (!g.nodes.has(S.city) || !g.nodes.has(H.city)) return bandOK(S, H, P);
  const L = dist(S, H);
  const dS = railDist(S.city), dH = railDist(H.city);
  if (dS[P.city] == null || dH[P.city] == null) return false;
  return (dS[P.city] + dH[P.city]) <= (state.ratioMax || RATIO_MAX) * L + 1e-6;
}
/* 区间级例外 */
function isBlack(S, H, P) {
  if (!P) return false;
  const c = s => (s && s.city ? s.city : '');
  for (const [a, b, d] of BLK2) {
    if (c(P) === d && ((c(S) === a && c(H) === b) || (c(S) === b && c(H) === a))) return true;
  }
  return false;
}
let _nearCache = null, _near50 = null;
/* ≤50km 邻接表(全站一次预计算, 避免每次重建 O(N²)) */
function near50Map() {
  if (_near50) return _near50;
  _near50 = {};
  const pts = STATIONS.map(sj => ({ lat: sj[2], lon: sj[3] }));
  for (let i = 0; i < STATIONS.length; i++) {
    const list = _near50[STATIONS[i][0]] = [];
    for (let j = 0; j < STATIONS.length; j++) {
      if (i === j) continue;
      if (dist(pts[i], pts[j]) <= 50) list.push(STATIONS[j][0]);
    }
  }
  return _near50;
}
/* 同城/紧邻: 与"区间内站"同城市名或 ≤50km (BFS传播; 长株潭/广佛实证) */
function nearOK(S, H) {
  const key = (S && S.name) + '|' + (H && H.name);
  if (_nearCache && _nearCache.key === key) return _nearCache.set;
  const set = new Set();
  const byCity = {};
  for (const s of STATIONS) (byCity[s[1]] = byCity[s[1]] || []).push(s);
  for (const s of STATIONS) {
    const P = { name: s[0], city: s[1], lat: s[2], lon: s[3] };
    if (bandOK(S, H, P) && chanOK(S, H, P)) set.add(P.name);
  }
  const n50 = near50Map();
  const q = [...set];
  while (q.length) {
    const cur = q.pop();
    for (const nb of (n50[cur] || [])) if (!set.has(nb)) { set.add(nb); q.push(nb); }
  }
  let added = true;
  while (added) {
    added = false;
    for (const s of STATIONS) {
      if (set.has(s[0])) continue;
      if ((byCity[s[1]] || []).some(x => set.has(x[0]))) { set.add(s[0]); added = true; }
    }
  }
  _nearCache = { key, set };
  return set;
}
/* 单点入区间判定(实测v2): 2=区间内(绿) 0=超区间(红) */
function beltV2(S, H, P, fast) {
  if (!S || !H || !P) return 0;
  if (isBlack(S, H, P)) return 0;
  if (dist(S, P) <= 50 || dist(H, P) <= 50) return 2; // 端点近邻/同城
  if (bandOK(S, H, P) && chanOK(S, H, P)) return 2;
  return (!fast && nearOK(S, H).has(P.name)) ? 2 : 0;
}

/* 端点内(t∈[0,1])允许宽带; 越出端点(t>1或t<0)仅允许贴线(实测: 越过端点偏离即拦截, 如 武汉↔广州→深圳) */
function coreLimit(L, t) { return (t > 1.0 || t < 0.0) ? 45 : Math.min(450, Math.max(60, 0.55 * L)); }
function edgeLimit(L, t) { return (t > 1.0 || t < 0.0) ? 60 : Math.min(520, Math.max(90, 0.75 * L)); }
/* 带 t 判定的走廊带(带宽依 t 是否越出端点变化) */
function ptArea(S, H, P, tLo, tHi, limitFn) {
  const L = dist(S, H);
  if (L < 15) return true;
  const { t, p } = corridor(S, H, P);
  return t >= tLo && t <= tHi && p <= limitFn(L, t);
}
function directCovered(S, H, D) {
  const L = dist(S, H);
  if (L < 15) return dist(S, D) <= 50;
  const { t, p } = corridor(S, H, D);
  return t >= -0.12 && t <= 1.12 && p <= coreLimit(L, t);
}

/* 行程判定 (O=出发地, D=目的地): 起点与终点都必须在区间内
   (实测规则: 票面发站/到站须在区间内 - 天津→济南 超出区间则不出售学生票) */
function planTrip(S, H, O, D) {
  const direct = dist(O, D);
  const L = dist(S, H);
  // 退化/同城区间(学校与端点几乎同点): 只允许近距离直达, 禁止经中转买任意远地
  if (L < 15 && direct > 150) return { ok: 0, mode: 'full', direct };
  // 实测v2: 票面两端(真正出发地+目的地)必须都在区间内 → 直达可出
  if (beltV2(S, H, O) !== 2 || beltV2(S, H, D) !== 2) return { ok: 0, mode: 'full', direct };
  return { ok: 1, mode: 'direct', direct };
}

/* 中转方案：经枢纽站 T，绕行 ≤ ratio×直达，T 贴近区间沿线，且起点 O 终点 D 都在区间内 */
function transferPlan(S, H, O, D) {
  if (!D) { D = O; O = S; } // 兼容旧3参调用(出发地=学校)
  const direct = dist(O, D);
  const limit = state.ratio * direct;
  const same = (a, b) => (a.name && a.name === b.name) ||
    (Math.abs(a.lat - b.lat) < 0.005 && Math.abs(a.lon - b.lon) < 0.005);
  // 硬约束①: 终点 D 必须在区间内(实测v2)
  if (beltV2(S, H, D) !== 2) return null;
  let best = null;
  for (const st of HUBS) {
    const T = { name: st[0], city: st[1], lat: st[2], lon: st[3] };
    if (same(T, D) || same(T, S) || same(T, O)) continue;
    const via = dist(O, T) + dist(T, D);
    if (via > limit) continue;
    if (beltV2(S, H, T) !== 2) continue;
    if (!best || via < best.via) best = { station: T, via, direct };
  }
  return best;
}

/* 单程规划：0 = 全价，1 = 优惠（直达或一次中转）；默认出发地=学校 */
function planOneWay(S, H, D, O) {
  if (O) return planTrip(S, H, O, D);
  return planTrip(S, H, S, D);
}
/* 给定家庭端 H，评估全部行程 */
function evalWith(H) {
  if (!state.school || !state.school.station || !H) return null;
  const S = state.school.station;
  const perTrip = state.trips.map(tp => {
    const D = tp.station;
    const p = planTrip(S, H, tp.from || S, D);
    const perWay = p.ok ? 1 : 0;
    return Object.assign({}, tp, { plan: p, used: tp.round ? perWay * 2 : perWay });
  });
  const used = perTrip.reduce((s, x) => s + x.used, 0);
  return {
    used,
    covered: perTrip.filter(x => x.plan.ok).length,
    direct: perTrip.filter(x => x.plan.mode === 'direct').length,
    transfer: perTrip.filter(x => x.plan.mode === 'transfer').length,
    fail: perTrip.filter(x => !x.plan.ok).length,
    perTrip,
  };
}
function evalAll() { return (state.home && state.home.station) ? evalWith(state.home.station) : null; }

/* ---------- 串联路线：多个目的地按顺序串成一条联程路线 ---------- */
/* 顺序: 起点 → D1 → D2 → ... → 终点。整条路线按联程计 1 次(单程方向)。
   校验: ① 每站终点在区间内(走廊带, 学校/家锚点自动通过) ② 无折返(相邻段方向夹角>90°) ③ 每前缀累计里程 ≤ ratio×从学校直达该点 */
function chainEval(S, H, stList, rStart, rEnd) {
  if (!S || !H) return null;
  if (!stList.length && !rEnd) return null;
  const start = rStart || S, end = rEnd || H;
  const pts = [start, ...stList, end];
  const direct = dist(S, H);
  const segs = [];
  let total = 0, maxRatio = 0, foldback = false, foldAt = null;
  const sameName = (a, b) => !!(a && b && a.name === b.name);
  for (let i = 0; i < pts.length - 1; i++) {
    const A = pts[i], B = pts[i + 1];
    const d = dist(A, B);
    total += d;
    let inInt = true;
    // 锚点(学校/家)自动通过; 其余每站(含自定义起点/终点)须在区间走廊带内
    const aAnchor = i === 0 && sameName(A, S);
    const bAnchor = i === pts.length - 2 && sameName(B, H);
    if (!aAnchor) {
      const { t, p } = corridor(S, H, A);
      if (!(t >= -0.15 && t <= 1.15 && p <= Math.max(60, 0.32 * direct))) inInt = false;
    }
    if (!bAnchor) {
      const { t, p } = corridor(S, H, B);
      if (!(t >= -0.15 && t <= 1.15 && p <= Math.max(60, 0.32 * direct))) inInt = false;
    }
    const ratio = total / dist(S, B);
    maxRatio = Math.max(maxRatio, ratio);
    if (i > 0) { // 折返检测: 段i-1方向 与 段i方向 夹角
      const a1 = pts[i - 1], b1 = pts[i], c1 = pts[i + 1];
      const ux = b1.lon - a1.lon, uy = b1.lat - a1.lat;
      const vx = c1.lon - b1.lon, vy = c1.lat - b1.lat;
      if (ux * vx + uy * vy < 0) { foldback = true; if (!foldAt) foldAt = B.name; }
    }
    segs.push({ from: A.name || '学校', to: B.name || '家', km: Math.round(d), inInt, ratio: +ratio.toFixed(2) });
  }
  return {
    segs, total: Math.round(total), direct: Math.round(direct),
    maxRatio: +maxRatio.toFixed(2), foldback, foldAt, pts,
    ok: !foldback && maxRatio <= state.ratio && segs.every(s => s.inInt),
  };
}
function chainEndPoint() { // 路线终点: 改终点优先, 否则最后一个地点
  return state.chainEnd || (state.trips.length ? state.trips[state.trips.length - 1].station : null);
}
function chainMidStations() { // 中间点: 有自定义终点时全部行程都是中间点
  return state.chainEnd ? state.trips.map(t => t.station) : state.trips.slice(0, -1).map(t => t.station);
}
function chainEvalCurrent() {
  const S = state.school && state.school.station;
  const H = state.home && state.home.station;
  const trips = state.trips;
  if (!trips.length && !state.chainEnd) return null;
  const start = state.routeStart || S;
  const end = chainEndPoint();
  return chainEval(S, H, chainMidStations(), start, end);
}
/* 最优分段规划: 整条无法联程时, 切成 连续区间内段(每组合1次联程) + 全价段, 总次数最少
   组断开条件: 段超区间 / 段间折返(方向回头) / 组内累计绕行超 ratio */
function planGroups(cc) {
  const c = cc || chainEvalCurrent();
  if (!c) return null;
  const S = state.school && state.school.station;
  const pts = c.pts || []; // 与 chainEval 完全一致的点序列
  const groups = [], full = [];
  let cur = null;
  c.segs.forEach((sg, i) => {
    const A = pts[i], B = pts[i + 1];
    let fold = false;
    if (i > 0 && pts[i - 1] && A && B) {
      const p0 = pts[i - 1];
      fold = (A.lon - p0.lon) * (B.lon - A.lon) + (A.lat - p0.lat) * (B.lat - A.lat) < 0;
    }
    if (!sg.inInt) { cur = null; full.push(sg); return; }
    if (fold) { // 折返: 不能与前段合并, 但本段可自成一组联程
      if (sg.km / dist(S, B) <= state.ratio) { cur = { segs: [sg], total: sg.km }; groups.push(cur); }
      else { cur = null; full.push(sg); }
      return;
    }
    const ratioOk = ((cur ? cur.total : 0) + sg.km) / dist(S, B) <= state.ratio;
    if (cur && ratioOk) { cur.segs.push(sg); cur.total += sg.km; return; }
    if (sg.km / dist(S, B) <= state.ratio) { cur = { segs: [sg], total: sg.km }; groups.push(cur); }
    else { cur = null; full.push(sg); }
  });
  return { groups, full, used: groups.length * (state.chainRound ? 2 : 1) };
}
function foldBackBadStation(c) {
  /* 折返能否靠排序修复: 按投影顺路排序后仍折返 → 返回出问题的站名(排序救不了); 否则 null(可排序修复) */
  if (!c || !c.foldback) return null;
  const S = state.school && state.school.station;
  const H = state.chainEnd || (state.home && state.home.station);
  if (!S || !H) return null;
  const sorted = state.trips.map(t => t.station).filter(Boolean)
    .sort((a, b) => corridor(S, H, a).t - corridor(S, H, b).t);
  const c2 = chainEval(S, H, (state.chainEnd ? sorted : sorted.slice(0, -1)), state.routeStart || S,
    state.chainEnd || (sorted.length ? sorted[sorted.length - 1] : H));
  return (c2 && c2.foldback) ? (c.foldAt || '某站') : null;
}
/* ---------- 车站/城市纯函数（无 DOM 依赖，供小程序版共用） ---------- */
function cleanCity(s) { return String(s || '').replace(/市|省|自治州|地区|盟|县|区|壮族|回族|维吾尔|苗|侗|布依|彝|土家族/g, ''); }
function stationOf(name) { return STATIONS.find(s => s[0] === name) || null; }
function nearestStation(pt, maxKm) {
  let best = null, bd = maxKm != null ? maxKm : Infinity;
  for (const s of STATIONS) {
    const d = dist({ lat: s[2], lon: s[3] }, pt);
    if (d < bd) { bd = d; best = s; }
  }
  return best;
}
function stToObj(s) { return s ? { name: s[0], city: s[1], lat: s[2], lon: s[3], hub: !!s[4] } : null; }
/* 联程路线判定(实测v2): 起点→…→终点 逐段两端均须在区间内(beltV2); 锚点站同样判定 */
function chainV2(S, H, stList, rStart, rEnd, fast) {
  if (!S || !H) return null;
  const start = rStart || S, end = rEnd || H;
  const pts = [start, ...(stList || []), end];
  const segs = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const A = pts[i], B = pts[i + 1];
    const seg = { a: A, b: B, km: dist(A, B), inInt: false, hub: null };
    if (beltV2(S, H, A, fast) === 2 && beltV2(S, H, B, fast) === 2) {
      seg.inInt = true; // 直达: 两端均区间内
    } else if (beltV2(S, H, A, fast) === 2) {
      // 中转可出(17点实测): 发站在区间内 + 唯一中转站T∈空间带(bandOK; 图外襄阳/武昌同城亦可用)
      // 首段 发站→T 两端在区间内; T→终到 段放行(含例外区/超带远站); 计次=全程1次(实测武汉→拉萨经郑州)
      let bestT = null, bestVia = Infinity;
      for (const sc of STATIONS) {
        if (sc[4] !== 1) continue; // 12306 中转站=枢纽级
        const T = { name: sc[0], city: sc[1], lat: sc[2], lon: sc[3] };
        if (T.name === A.name || T.name === B.name || T.name === H.name || T.name === S.name) continue;
        if (!bandOK(S, H, T)) continue;
        const via = dist(A, T) + dist(T, B);
        if (via < bestVia) { bestVia = via; bestT = T.name; }
      }
      if (bestT) seg.hub = bestT;
    }
    seg.ok = seg.inInt || seg.hub != null;
    segs.push(seg);
  }
  const okN = segs.filter(sg => sg.ok).length;
  return { segs, okN, total: segs.reduce((s, x) => s + x.km, 0), okAll: okN === segs.length };
}

/* ============ 极简界面逻辑 ============ */
const $ = id => document.getElementById(id);
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function showStep(name){
  document.querySelectorAll('.step').forEach(el=>el.classList.remove('on'));
  const el=$('step'+name); if(!el)return;
  el.classList.add('on');
  const inp=el.querySelector('input[type=text]');
  if(inp)setTimeout(()=>{try{inp.focus();}catch(e){}},60); // 自动聚焦到输入框
}
function prevStep(name){
  const el=$('step'+name); if(!el)return;
  const inp=el.querySelector('input[type=text]');
  if(inp){inp.readOnly=false;inp.style.color='';} // 返回可修改
  showStep(name);
}
function resolvePlace(q){
  q=String(q||'').trim();
  const qn=cleanCity(q);
  const hits=STATIONS.filter(s=>s[0]===qn||s[1]===qn||s[1].includes(qn)||qn.includes(s[1]));
  if(!hits.length)return null;
  const h=hits.find(s=>s[4])||hits[0];
  return {point:{lat:h[2],lon:h[3]},station:{name:h[0],city:h[1],lat:h[2],lon:h[3]}};
}
function nextSchool(){
  const r=resolvePlace($('schoolInput').value);
  if(!r){setErr('stepSchool','未收录该站，试试输入 城市名 或 车站名');return;}
  state.school={text:$('schoolInput').value.trim(),point:r.point,station:r.station};
  $('schoolInput').value=r.station.name;
  showStep('Home');
}
function nextHome(){
  const r=resolvePlace($('homeInput').value);
  if(!r){setErr('stepHome','未收录该站');return;}
  state.home={text:$('homeInput').value.trim(),point:r.point,station:r.station};
  state.depart=state.home.station; // 出发地=家; 采用推荐只改"家"端点, 出发地固定
  $('homeInput').value=r.station.name;
  locateDepartLine();
  showStep('Trips');
}
function setErr(step,t){const e=document.querySelector('#'+step+' .err');if(e)e.textContent=t;}
function addTrip(){
  const q=$('tripInput').value.trim();
  if(!q)return;
  const r=resolvePlace(q);
  if(!r){$('tripErr').textContent='未收录「'+q+'」';return;}
  $('tripErr').textContent='';
  state.trips.push({id:++state._tid,text:q,point:r.point,station:r.station,round:false});
  $('tripInput').value='';
  planned=false;
  renderTrips();renderResult();
}
let dragId=null;
function tStart(e,id){dragId=id;if(e.dataTransfer){e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',id);}}
function tOver(e,id){e.preventDefault();if(e.dataTransfer)e.dataTransfer.dropEffect='move';document.querySelectorAll('.trip').forEach(r=>r.classList.remove('drag-over'));if(e.currentTarget)e.currentTarget.classList.add('drag-over');}
function tDrop(e,id){
  e.preventDefault();
  document.querySelectorAll('.trip').forEach(r=>r.classList.remove('drag-over'));
  if(dragId==null||dragId===id){dragId=null;return;}
  const i=state.trips.findIndex(t=>t.id===dragId),j=state.trips.findIndex(t=>t.id===id);
  if(i<0||j<0){dragId=null;return;}
  const [it]=state.trips.splice(i,1);
  state.trips.splice(j,0,it);
  dragId=null;planned=false;
  renderTrips();renderResult();
}
function renderTrips(){
  const el=$('tripList');
  if(!state.trips.length){el.innerHTML='<div style="color:var(--mut2);font-size:12.5px;padding:4px 2px">还没有目的地（顺序=路线顺序，可拖动排序）</div>';return;}
  el.innerHTML=state.trips.map(t=>{
    return '<div class="trip" draggable="true" data-drag="'+t.id+'">'+
      '<span class="grip" title="拖动排序">⠿</span>'+
      '<div class="t"><div>'+esc(t.text)+'</div>'+
      '<div class="route">第 '+(state.trips.indexOf(t)+1)+' 程</div></div>'+
      '<button class="del" data-rm="'+t.id+'">×</button></div>';
  }).join('');
}
function rm(id){state.trips=state.trips.filter(t=>t.id!==id);planned=false;renderTrips();renderResult();}
function clearAll(){state.trips=[];planned=false;renderTrips();renderResult();$('tripInput').focus();}
function setRound(v){state.trips.forEach(t=>t.round=v);planned=false;renderTrips();renderResult();}
let planned=false;
function routeChainAt(S,H2){
  const sts=state.trips.map(t=>t.station);
  const dep=state.depart||H2;
  if(roundAny()) return chainV2(S,H2,sts,dep,dep);           // 全程往返: 出发→各程→回出发
  if(!sts.length) return chainV2(S,H2,[],dep,dep);
  return chainV2(S,H2,sts.slice(0,-1),dep,sts[sts.length-1]); // 单程: 出发→各程(终点=最后一程, 不重复)
}
function routeChain(S,H){return routeChainAt(S,H);}
/* 区间内可选中转站(空间带, 仅供弹窗展示候选) */
let tfmHubs=[];
function hubsInBand(S,H){
  const out=[];const Ld=dist(S,H);
  for(const sc of STATIONS){
    if(sc[4]!==1)continue;
    const T={name:sc[0],city:sc[1],lat:sc[2],lon:sc[3]};
    if(T.name===S.name||T.name===H.name)continue;
    if(!bandOK(S,H,T))continue;
    out.push({name:T.name,city:T.city,km:Math.round(dist(S,T))});
  }
  out.sort((a,b)=>a.km-b.km);
  return out.slice(0,8);
}
/* 自动最优排序: 使最多路段落在区间内(联程段覆盖), 平局取总里程短 */
function bestRoute(S,H,trips){
  const arr=trips.slice();
  if(arr.length<=1)return arr;
  // 原始输入顺序: 同次数时优先保留用户先后
  const want=arr.map((t,i)=>i).slice();
  const sts=arr.map(t=>t.station);
  const ticketCount=oks=>{let t=0,r=0;for(const o of oks){if(o)r++;else{t+=Math.ceil(r/2);r=0;}}return t+Math.ceil(r/2);};
  const evalOrder=ord=>{
    const oks=[];let dirN=0,km=0,prev=H,sim=0;
    for(let k=0;k<ord.length;k++){const i=ord[k],q=sts[i];
      const d=beltV2(S,H,prev)===2&&beltV2(S,H,q)===2;
      oks.push(d);if(d)dirN++;
      if(ord[k]===want[k])sim++;
      km+=dist(prev,q);prev=q;}
    km+=dist(prev,H);
    return{tickets:ticketCount(oks),okN:oks.filter(Boolean).length,dirN,sim,km};
  };
  const better=(a,b)=> a.tickets!==b.tickets?a.tickets<b.tickets
    :a.okN!==b.okN?a.okN>b.okN
    :a.dirN!==b.dirN?a.dirN>b.dirN
    :a.sim!==b.sim?a.sim>b.sim
    :a.km<b.km;
  const n=arr.length;
  let bestOrd=null,bestScore=null;
  if(n<=9){
    const perm=[],used=new Array(n).fill(0);
    (function dfs(){
      if(perm.length===n){
        const sc=evalOrder(perm);
        if(!bestScore||better(sc,bestScore)){bestScore=sc;bestOrd=perm.slice();}
        return;
      }
      for(let i=0;i<n;i++)if(!used[i]){used[i]=1;perm.push(i);dfs();used[i]=0;perm.pop();}
    })();
  }else{
    let cur=H,ord=[],left=sts.map((_,i)=>i);
    while(left.length){
      let bi=0,bd=Infinity;
      for(let k=0;k<left.length;k++){const d=dist(cur,sts[left[k]]);if(d<bd){bd=d;bi=k;}}
      ord.push(left[bi]);cur=sts[left[bi]];left.splice(bi,1);
    }
    let improved=true;
    while(improved){
      improved=false;
      for(let i=0;i<n-1;i++){
        const a=ord.slice(),tmp=a[i];a[i]=a[i+1];a[i+1]=tmp;
        const sa=evalOrder(ord),sb=evalOrder(a);
        if(better(sb,sa)){ord=a;improved=true;}
      }
    }
    bestOrd=ord;
  }
  return bestOrd.map(i=>arr[i]);
}
function roundAny(){return state.trips.some(t=>t.round);}
function onPlan(){
  if(!state.school||!state.home){$('tripErr').textContent='请先完成 学校 与 出发地';return;}
  hubOverride={}; // 新规划重置中转选择
  if($('tripInput').value.trim()) addTrip(); // 忘记点添加? 自动补入
  if(!state.trips.length){$('tripErr').textContent='还没有目的地';return;}
  statsPlan();
  // 自动按最优联程排序: 使最多段落在区间内
  state.trips=bestRoute(state.school.station,state.home.station,state.trips);
  planned=true;renderTrips();renderResult();
}
function renderResult(){
  const el=$('result');
  if(!planned||!state.school||!state.home||!state.trips.length){el.innerHTML='';return;}
  const S=state.school.station,H=state.home.station;
  const cc=routeChain(S,H);
  cc.segs.forEach((sg,i)=>{ if(hubOverride[i]) sg.hub=hubOverride[i]; sg.ok=sg.inInt||sg.hub!=null; });
  const N=cc.segs.length,okN=cc.okN;
  let used=0, remain=Math.max(0,state.budget);
  const sup=chainBestLocal();
  const curCover=cc.okN, curDirN=cc.segs.filter(sg=>sg.inInt).length;
  const hubN=cc.segs.filter(sg=>sg.hub).length;
  const dirN=cc.segs.filter(sg=>sg.inInt).length;
  // 计次: 连续可出段=同一趟行程(无绕路,非往返)→1次; 区间外断程切分; 往返×2
  const okRuns = [];
  let curR = [];
  cc.segs.forEach((sg, i) => {
    if (i < state.trips.length && sg.ok) curR.push(i);
    else if (curR.length) { okRuns.push(curR); curR = []; }
  });
  if (curR.length) okRuns.push(curR);
  used = Math.max(1, okRuns.length) * (roundAny() ? 2 : 1);
  remain = Math.max(0, state.budget - used);
  tfmHubs=cc.segs.map(sg=>sg.hub?hubsInBand(S,H):[]);
  const hubLineHtml=hubN?('<div style="font-size:11px;color:var(--warn);font-weight:600;margin-top:2px">中转 '+hubN+' 段：'+cc.segs.map((sg,i)=>sg.hub?('第'+(i+1)+'程 经'+esc(sg.hub)):null).filter(Boolean).join('、')+'</div>'):'';
  let html='<div class="card" id="resCard">'+
    (adoptNote?'<div class="rec" style="margin-bottom:10px">'+adoptNote+'</div>':'')+
    '<div class="sum">'+
    (cc.okAll?'联程全程可出':'<b>'+okN+'/'+N+'</b> 段可出 · '+(N-okN)+' 段需另购')+
    hubLineHtml+
    '<div style="font-size:11px;color:var(--ok);font-weight:600;margin-top:2px">连续联程（无绕路·非往返）：'+okRuns.length+' 趟行程 · 共 '+used+' 次'+(roundAny()?'（往返×2）':'')+' · 剩余 '+remain+' 次</div>'+
    '<div style="font-size:11.5px;color:var(--mut);font-weight:500;margin-top:2px">其中 直达 '+dirN+' 段 · 数优先直达，实在没有才用中转</div>'+
    '</div><div class="note">出发地 '+esc((state.depart||H).name)+' · 区间 '+esc(S.name)+' ⇄ '+esc(H.name)+' · '+
    (cc.okAll?'全程联程 <b>'+used+'</b> 次 · 剩余 <b>'+remain+'</b> 次':'按 分段/搭桥 另计')+'</div>';
  // 路线串联图: 站点chips + 段箭头着色 (与 routeChain 同构: 往返才带回程)
  html+='<div style="display:flex;flex-wrap:wrap;align-items:center;gap:0 6px;margin-bottom:12px;font-size:13px">';
  const depPt=state.depart||H, stsPt=state.trips.map(t=>t.station);
  const pts=roundAny()?[depPt,...stsPt,depPt]:(stsPt.length?[depPt,...stsPt]:[depPt]);
  for(let i=0;i<pts.length;i++){
    if(i>0){
      const sgA=cc.segs[i-1];
      html+='<span style="color:'+(sgA.inInt?'var(--ok)':sgA.hub?'var(--warn)':'var(--no)')+';font-weight:800">'+(sgA.inInt||sgA.hub?'→':'⇢')+'</span>';
      if(sgA.hub&&!sgA.inInt){
        html+='<span class="chip warn">'+esc(sgA.hub)+'<span style="display:block;font-size:9px;color:#d97706;font-weight:700;line-height:1.15">中转站</span></span>';
      }
    }
    const badAdj=(i>0&&!cc.segs[i-1].ok)||(i<pts.length-1&&!cc.segs[i].ok);
    html+='<span class="chip '+(badAdj?'no':'ok')+'">'+esc(pts[i].name)+'</span>';
  }
  html+='</div>';
  if(!cc.okAll){
    html+='<div style="margin-bottom:8px">'+cc.segs.map((sg,i)=>{
      const lbl=(roundAny()&&i===cc.segs.length-1)?'回程':'第'+(i+1)+'程';
      const cands=tfmHubs[i]||[];
      const NUMS2=['①','②','③','④','⑤','⑥','⑦','⑧'];
      const cands4=cands.slice(0,4); // 最多4个, 两行两列
      const hubLine=(sg.hub&&cands4.length&&!sg.inInt)?'<div style="margin-top:6px;font-size:11px;color:var(--mut)">最终中转可选：'+
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-top:4px">'+
        cands4.map((c,j)=>'<span class="hub-badge" style="margin:0;'+(c.name===sg.hub?'background:var(--warn-soft);border-color:#d97706':'')+'" data-hub="'+i+','+j+'">'+NUMS2[j]+esc(c.name)+'</span>').join('')+'</div></div>':'';
      return '<div style="display:flex;align-items:flex-start;gap:10px;padding:9px 11px;border:1px solid var(--line);border-radius:12px;margin-bottom:7px;background:#fff">'+
      '<div style="flex:1;font-size:12.5px;color:var(--mut)"><b style="color:var(--ink)">'+lbl+' '+esc(sg.a.name)+' → '+(sg.hub?'<span style="color:#d97706">'+esc(sg.hub)+'</span> → ':'')+esc(sg.b.name)+'</b>'+
      (sg.inInt?'<span class="chip ok" style="margin-left:8px">✓ 区间内·直达</span>':sg.hub?'<span class="chip ok" style="margin-left:8px">✓ 可出·中转</span>':'<span class="chip no" style="margin-left:8px">✕ 区间外·需购成人票</span>')+hubLine+'</div>'+
      (sg.inInt?'':sg.hub?'<span class="hub-badge" data-tfm="'+i+'">⇄ 可中转哪里出票·推荐'+esc(sg.hub)+'</span>':'')+
      '</div>';
    }).join('')+'</div>';
    html+='<div class="bridge">⚠ '+(N-okN)+' 段不可出：可<b>分段购买</b>（区间内/中转段学生票+其余全价）；或先购「区间内 → '+esc(H.name)+'」合法票再购后续段（搭桥法，实测有效），最后退掉第一张。</div>';
  }
  if(sup&&sup.st){
    const betterCover=sup.cover>curCover;
    const betterDir=!betterCover&&sup.dirN>curDirN;
    html+=(betterCover
      ?'<div class="rec">把<b>家</b>改成 <b>'+esc(sup.st.name)+' · '+esc(sup.st.city)+'</b> → 联程可出 <b>'+sup.cover+'/'+N+'</b> 段'+(sup.cover<N?'（最高）':'')+
        '<div class="mini">覆盖优先 · p/L='+sup.pMax.toFixed(2)+'（越居中越稳）</div></div>'+
        '<button class="btn" style="margin-top:8px" data-adopt="'+sup.st.name+'">采用推荐区间</button>'
      :betterDir
        ?'<div class="rec">把<b>家</b>改成 <b>'+esc(sup.st.name)+' · '+esc(sup.st.city)+'</b> → 该段变为<b>直达</b>，无需中转'+
          '<div class="mini">覆盖不变 · 直达段更多 · p/L='+sup.pMax.toFixed(2)+'</div></div>'+
          '<button class="btn" style="margin-top:8px" data-adopt="'+sup.st.name+'">采用推荐区间</button>'
        :'<div class="rec">当前区间已是最优（联程 '+curCover+'/'+N+' 段'+(curDirN?('，直达 '+curDirN+' 段'):'，均需中转')+'），无更好的家端点</div>');
  }
  html+='<details><summary>🎫 次数明细（连续行程怎么计）</summary>'+
    okRuns.map((run, ri) => {
      const segs = run.map(j => cc.segs[j]);
      const path = segs.map(x => esc(x.a.name) + '→' + esc(x.b.name)).join('→');
      const tags = segs.map(x => x.inInt ? '直达' : '中转·经' + esc(x.hub)).join(' / ');
      return '<div class="mini-row"><div class="n">行程' + (ri + 1) + ' ' + path + '</div><div class="d">全程联程（无绕路）· 计 1 次（' + tags + '）</div></div>';
    }).join('') +
    cc.segs.filter((sg, i) => i < state.trips.length && !sg.ok).map(sg =>
      '<div class="mini-row"><div class="n">区间外 ' + esc(sg.a.name) + '→' + esc(sg.b.name) + '</div><div class="d">需购成人票（此段断开行程）</div></div>').join('') +
    '<div style="font-size:11.5px;color:var(--mut);margin-top:6px">规则：同一趟连续行程（不折返、不往返）无论分几张票/几次中转，全程计 1 次；勾全程往返则 ×2；区间外段需成人票并断开行程。</div>'+
    '</details>';
  html+='<details><summary>更多家端点（区间优化）</summary>'+optRows()+'</details>';
  html+='<details><summary>参数：绕远倍数（通道判定上限）</summary>'+paramHTML()+'</details>';
  html+='</div>';
  el.innerHTML=html;
  adoptNote='';
}
function chainBestLocal(){
  const S=state.school.station,H=state.home.station;
  const sts=state.trips.map(t=>t.station);
  const curCover=routeChain(S,H).okN;
  let best=null;
  for(const s of STATIONS){
    if(s[0]===S.name)continue;
    if(!railAdj().nodes.has(s[1]))continue;
    if(s[1]===H.city)continue; // 不再推荐当前家的同城站
    const H2={name:s[0],city:s[1],lat:s[2],lon:s[3]};
    const cc=routeChainAt(S,H2);
    const cover=cc.okN;
    if(cover<curCover)continue;
    const Lh=dist(S,H2);
    let pMax=0,dirN=0;
    for(const sg of cc.segs){ if(sg.inInt)dirN++; if(sg.inInt){const{p}=corridor(S,H2,sg.b);pMax=Math.max(pMax,p/(Lh||1));} }
    const km=dist({lat:s[2],lon:s[3]},{lat:H.lat,lon:H.lon});
    // 覆盖→直达段多→p/L小→距家近 (优先满足直达, 中转兜底)
    if(!best||cover>best.cover||(cover===best.cover&&(dirN>best.dirN||(dirN===best.dirN&&(pMax<best.pMax||(pMax===best.pMax&&km<best.km))))))
      best={st:{name:s[0],city:s[1],lat:s[2],lon:s[3]},cover,dirN,pMax};
  }
  return best;
}
function optRows(){
  const S=state.school.station,H=state.home.station;
  const sts=state.trips.map(t=>t.station);
  const rows=[];
  for(const s of STATIONS){
    if(s[0]===S.name)continue;
    if(!railAdj().nodes.has(s[1]))continue;
    if(s[1]===H.city)continue;
    const H2={name:s[0],city:s[1],lat:s[2],lon:s[3]};
    const cc=routeChainAt(S,H2);
    if(!cc||cc.okN===0)continue;
    rows.push({s,cover:cc.okN});
  }
  rows.sort((a,b)=>b.cover-a.cover);
  return rows.slice(0,8).map(r=>'<div class="mini-row"><div class="n">'+esc(r.s[0])+' · '+esc(r.s[1])+'</div><div class="d">联程可出 '+r.cover+'/'+(sts.length+2)+' 段</div>'+
    '<button class="ghost" data-adopt="'+r.s[0]+'">采用</button></div>').join('');
}
let tfmSeg = null, tfmIdx = -1, tfmStep = 1;
let hubOverride = {};
function setHub(i,j){
  const cands=tfmHubs[i]||[];
  const c=cands[j]; if(!c)return;
  hubOverride[i]=c.name;   // 该段最终中转=所选站
  renderResult();
}
function openTfm(i){
  const S=state.school.station,H=state.home.station;
  const cc=routeChain(S,H);
  tfmSeg=cc.segs[i]; tfmIdx=i; tfmStep=1;
  if(!tfmSeg||!tfmSeg.hub)return;
  document.getElementById('tfm').style.display='flex';
  tfmRender();
}
function tfmRender(){
  const S=state.school.station,H=state.home.station;
  const b=document.getElementById('tfmBody');
  const cands=tfmHubs[tfmIdx]||[]; // 已按距发站推荐从高到低排序
  if(tfmStep===1){
    b.innerHTML='<div class="tfm-step"><span class="n">1</span><div><b>区间不用改</b>：保持<b>优惠区间为 '+esc(S.name)+' ⇄ '+esc(H.name)+'</b> 不变，只做中转。</div></div>';
  }else if(tfmStep===2){
    const NUMS=['①','②','③','④','⑤','⑥','⑦','⑧'];
    const chips=cands.map((c,j)=>'<span class="hub-badge" style="margin:4px;'+(c.name===tfmSeg.hub?'background:var(--warn-soft);border-color:#d97706':'')+'" data-tfmpick="'+j+'">'+NUMS[j]+esc(c.name)+'</span>').join('');
    b.innerHTML='<div class="tfm-step"><span class="n">2</span><div>选择在 12306 上<b>可以中转的地点</b>（①推荐 ②次选…，点选后以下步骤以它为例）：<div style="margin-top:8px">'+chips+'</div></div></div>';
  }else if(tfmStep===3){
    b.innerHTML='<div class="tfm-step"><span class="n">3</span><div>在 12306 购票时选「<b>中转</b>」，中转站填 <b>'+esc(tfmSeg.hub)+'</b>。</div></div>'+
      '<div class="tfm-step"><span class="n">4</span><div>首段 <b>'+esc(tfmSeg.a.name)+' → '+esc(tfmSeg.hub)+'</b> 按学生票购买（两端都在区间内）。</div></div>';
  }else{
    b.innerHTML='<div class="tfm-step"><span class="n">5</span><div>后续段 <b>'+esc(tfmSeg.hub)+' → '+esc(tfmSeg.b.name)+'</b> 随联程放行，全程计 1 次优惠。</div></div>'+
      '<div class="tfm-note">实际以 12306 出票为准；若该中转站没有合适的后续车，回到上一步换一个站。</div>';
  }
  document.getElementById('tfmNext').style.display = tfmStep===4?'none':'';
  document.getElementById('tfmPrev').style.display = tfmStep===1?'none':'';
  document.getElementById('tfmNext').textContent = tfmStep===2&&document.getElementById('tfmNext') ? (tfmStep===2?'下一步':'下一步') : '下一步';
}
function tfmPick(j){
  const c=tfmHubs[tfmIdx][j];
  if(!c||!tfmSeg)return;
  tfmSeg.hub=c.name; // 后续步骤以该站为例
  tfmStep=3; tfmRender();
}
function tfmNext(){ if(tfmSeg) tfmStep=Math.min(4,tfmStep+1); tfmRender(); }
function tfmPrev(){ if(tfmSeg) tfmStep=Math.max(1,tfmStep-1); tfmRender(); }
function closeTfm(){document.getElementById('tfm').style.display='none';tfmSeg=null;}
function adopt(name){
  const r=resolvePlace(name);
  if(!r)return;
  state.home={text:r.station.name,point:r.point,station:r.station};
  // 出发地(state.depart)保持不变 — 只改区间端点(家)
  locateDepartLine();
  adoptNote='已按推荐改 <b>家</b> 为 '+esc(r.station.name)+'；出发地（'+esc((state.depart||state.home.station).name)+'）不变，已按新区间 '+esc(state.school.station.name)+' ⇄ '+esc(r.station.name)+' 重新判定。';
  onPlan();
}
let adoptNote='';
function locateDepartLine(){
  const d=state.depart||(state.home&&state.home.station);
  $('depLine').innerHTML='出发地：<b>'+esc(d?d.name:'——')+'</b><span>（固定不变；推荐只改"家"端点）</span>';
}
function paramHTML(){
  const v=state.ratioMax;
  return '<div style="font-size:12.5px;color:var(--mut)">当前 '+v+'（默认 2.5 · 用户值 localStorage 优先）</div>'+
    '<input type="range" id="ratioRange" min="1" max="6" step="0.1" value="'+v+'" >'+
    '<div class="param-line"><span>1（严格）</span><span style="flex:1;text-align:center">更小=更严 · 2.5=实测最优</span><span>6（宽松）</span></div>'+
    '<button class="ghost" data-reset="">↺ 重置 2.5</button>';
}
function setRatio(v){
  state.ratioMax=Math.min(20,Math.max(1,+v||2.5));
  try{localStorage.setItem('srp_ratioMax',state.ratioMax);}catch(e){}
  _nearCache=null;
  renderTrips();renderResult();
}
function resetRatio(){
  try{localStorage.removeItem('srp_ratioMax');}catch(e){}
  state.ratioMax=2.5;_nearCache=null;
  renderTrips();renderResult();
}
(function(){
  try{
    const raw=localStorage.getItem('srp_ratioMax');
    state.ratioMax=(raw&&isFinite(+raw)&&+raw>=1&&+raw<=20)?+raw:2.5;
  }catch(e){state.ratioMax=2.5;}
  state.budget=4;
  statsVisit();
})();
/* 访问/规划统计(本地) */
function statsRead(){try{return JSON.parse(localStorage.getItem('srp_stats'))||{v:0,p:0};}catch(e){return{v:0,p:0};}}
function statsWrite(s){try{localStorage.setItem('srp_stats',JSON.stringify(s));}catch(e){}}
function statsVisit(){let s=statsRead();let seen=false;try{seen=sessionStorage.getItem('srp_seen')==='1';}catch(e){}if(!seen){s.v++;statsWrite(s);try{sessionStorage.setItem('srp_seen','1');}catch(e){}}statsShow();}
function statsPlan(){const s=statsRead();s.p++;statsWrite(s);statsShow();}
function statsShow(){/* 仅后台统计, 不显示 */}
window.addEventListener('error',()=>{});

/* ===== 小红书容器绑定(替换行内事件) ===== */
(function () {
  function on(id, ev, fn) { var el = document.getElementById(id); if (el) el.addEventListener(ev, fn); }
  on('schoolInput', 'keydown', function (e) { if (e.key === 'Enter') nextSchool(); });
  on('homeInput', 'keydown', function (e) { if (e.key === 'Enter') nextHome(); });
  on('tripInput', 'keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); addTrip(); } });
  on('btnSchool', 'click', nextSchool);
  on('btnHome', 'click', nextHome);
  on('btnAdd', 'click', addTrip);
  on('btnPlan', 'click', onPlan);
  on('btnClear', 'click', clearAll);
  on('btnBackHome', 'click', function () { prevStep('School'); });
  on('btnBackTrips', 'click', function () { prevStep('Home'); });
  on('btnReset', 'click', resetRatio);
  on('tfmNext', 'click', tfmNext);
  on('tfmPrev', 'click', tfmPrev);
  on('tfmClose', 'click', closeTfm);
  on('tfmMask', 'click', function (e) { if (e.target === this) closeTfm(); });
  on('roundAll', 'change', function (e) { setRound(e.target.checked); });
  /* 范围滑杆: 页面内任意 id=ratioRange 元素(静态+弹窗模板)统一走 input 委托 */
  document.addEventListener('input', function (ev) { if (ev.target && ev.target.id === 'ratioRange') setRatio(parseFloat(ev.target.value)); });
  /* 动态元素点击委托 */
  document.addEventListener('click', function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest('[data-rm],[data-adopt],[data-tfm],[data-hub],[data-tfmpick],[data-reset]') : null;
    if (!t) return;
    if (t.hasAttribute('data-rm')) rm(parseInt(t.getAttribute('data-rm'), 10));
    else if (t.hasAttribute('data-adopt')) adopt(t.getAttribute('data-adopt'));
    else if (t.hasAttribute('data-tfm')) openTfm(parseInt(t.getAttribute('data-tfm'), 10));
    else if (t.hasAttribute('data-hub')) { var p = t.getAttribute('data-hub').split(','); setHub(parseInt(p[0], 10), parseInt(p[1], 10)); }
    else if (t.hasAttribute('data-tfmpick')) tfmPick(parseInt(t.getAttribute('data-tfmpick'), 10));
    else if (t.hasAttribute('data-reset')) resetRatio();
  });
  /* 行程拖动委托(原为行内 ondragstart/ondragover/ondrop) */
  document.addEventListener('dragstart', function (ev) { var t = ev.target && ev.target.closest ? ev.target.closest('[data-drag]') : null; if (t) tStart(ev, parseInt(t.getAttribute('data-drag'), 10)); });
  document.addEventListener('dragover', function (ev) { var t = ev.target && ev.target.closest ? ev.target.closest('[data-drag]') : null; if (t) tOver(ev, parseInt(t.getAttribute('data-drag'), 10)); });
  document.addEventListener('drop', function (ev) { var t = ev.target && ev.target.closest ? ev.target.closest('[data-drag]') : null; if (t) tDrop(ev, parseInt(t.getAttribute('data-drag'), 10)); });
})();
